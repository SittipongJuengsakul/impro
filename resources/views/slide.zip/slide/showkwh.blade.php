<div style="background-color: white;">
            <div class="row">
                  <div class="col-md-12" style="padding-top: 10%;">
                        <form class="form-inline" style="text-align:center">
                          <div class="form-group showleft">
                            วันนี้ไช้
                          </div>
                          <div class="form-group showcenter" id="showkwh_todayuse">

                          </div>
                          <div class="form-group showright">
                            kWh
                          </div>
                        </form>
                        <form class="form-inline" style="text-align:center">
                          <div class="form-group showleft">
                            สะสมเดือนนี้
                          </div>
                          <div class="form-group showcenter" id="showkwh_tomonthuse">

                          </div>
                          <div class="form-group showright">
                            kWh
                          </div>
                        </form>
                        <form class="form-inline" style="text-align:center">
                          <div class="form-group showleft">
                            สะสมปีนี้
                          </div>
                          <div class="form-group showcenter" id="showkwh_toyearuse">

                          </div>
                          <div class="form-group showright">
                            kWh
                          </div>
                        </form>
                  </div>
            </div>
</div>
