<div style="background-color: white;">
            <div class="row">
                  <div class="col-md-12">
                    <h1>ค่าการใช้พลังงาน Chiller Plant</h1><? $monthd = date("m"); ?>
                    <h2 style="margin-top: 0px;">{{ Carbon\Carbon::now()->format('d') }} เดือน <?
                    echo $month; ?> {{ Carbon\Carbon::now()->format('Y')+543 }}</h2>
                    <div id="container_chiller_plant_all" style="margin: 0 auto;min-height: 500px"></div>
                  </div>
            </div>
</div>
