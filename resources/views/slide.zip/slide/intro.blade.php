<div style="background-color: white;">
            <div class="row">
                  <div class="col-md-12">
                    <div class="col-md-6">
                      <img src="{{ URL::asset('assets/img/energysave.png') }}" alt="" style="width: 100%;"/>
                    </div>
                    <div class="col-md-6">
                      <h1>คณะทำงาน 4 คณะประกอบด้วย</h1>
                      <h2>1. คณะทำงานด้านการจัดการพลังงาน (ทกพ.)</h2>
                      <h2>2. คณะผู้ตรวจประเมินการจัดการพลังงาน</h2>
                      <h2>3. คณะทำงานส่งเสริมการอนุรักษ์พลังงาน</h2>
                      <h2>4. คณะผู้ส่งเสริมและสนับสนุนการประหยัดพลังงาน</h2>
                    </div>
                  </div>
            </div>
</div>
