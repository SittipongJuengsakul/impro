<div style="background-color: white;">
            <div class="row">
                  <div class="col-md-12">
                    <h1>การใช้พลังงานกลุ่มที่ 8</h1>
                    <div id="container_energy_g8" style="margin: 0 auto;min-height: 500px"></div>
                  </div>
            </div>
</div>
