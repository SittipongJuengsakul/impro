<div style="background-color: white;">
            <div class="row">
                  <div class="col-md-12">
                    <img src="{{ URL::asset('assets/img/mapbot.png') }}" alt="" style="height: 600px;margin-left:13%;"/>
                  </div>
            </div>
</div>
